armazem = {};

armazem[987001] = {
    nome: "Caneta Azul",
    preco: 2.99
};
armazem[987002] = {
    nome: "Caneta Vermelha de Gel",
    preco: 6.50
};
armazem[987003] = {
    nome: "Caderno A5",
    preco: 60.00
};
armazem[987004] = {
    nome: "Estojo Rosa",
    preco: 23.99
};
armazem[987005] = {
    nome: "Lápis Preto",
    preco: 1.98
};

console.table(armazem);